﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GreatOutdoors.MVC.Models
{
    public class SalesPersonViewModel
    {
        public Guid SalespersonID { get; set; }

        [Required(ErrorMessage = "Name can't be blank")]
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "Name should contain only alphabets")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Mobile number can't be blank")]
        [RegularExpression("^([9]{1})([234789]{1})([0-9]{8})$", ErrorMessage = "Please enter valid mobile number")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Email can't be blank")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
            ErrorMessage = "Please enter valid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password can't be blank")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})", ErrorMessage = "Password should be 6 to 15 characters with at least one digit, one uppercase letter, one lower case letter.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Date of joining can't be blank")]
        public DateTime JoiningDate { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "City should contain only alphabets")]
        public string City { get; set; }
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "State should contain only alphabets")]
        public string State { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter only numbers")]
        public string Pincode { get; set; }

        [Required(ErrorMessage = "Date of birth can't be blank")]
        public DateTime Birthdate { get; set; }
        public Nullable<DateTime> LastAccountModifiedDateTime { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Salary { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Bonus { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Target { get; set; }
    }
}
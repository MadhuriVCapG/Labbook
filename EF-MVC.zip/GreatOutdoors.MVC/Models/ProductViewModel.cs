﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace GreatOutdoors.MVC.Models
{
    public class ProductViewModel
    {
        public Guid ProductID { get; set; }

        [Required(ErrorMessage ="Name can't be blank")]
        [RegularExpression("^[A-Za-z ]*$",ErrorMessage ="Name should contain only alphabets")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Category should be selected")]
        public string Category { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter only integers")]
        public Nullable<int> Stock { get; set; }


        public string Size { get; set; }
        [Required(ErrorMessage = "Colour can't be blank")]
        public string Colour { get; set; }

        [Required(ErrorMessage = "Technical specifications can't be blank")]
        public string TechnicalSpecifications { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> CostPrice { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> SellingPrice { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> DiscountPercentage { get; set; }
        
    }
}
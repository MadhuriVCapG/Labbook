﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class SalesPersonsController : Controller
    {
        // GET: SalesPersons
        public ActionResult Index()
        {
            //Create an object of Salesperson ViewModel
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            //Calling View and passing object to View
            return View(salesPersonViewModel);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class ProductsController : Controller
    {
        // URL:Products/Index
        public ActionResult Create()
        {
            //Creating ViewModel object
            ProductViewModel productViewModel = new ProductViewModel();

            //Calling View and passing ViewModel object to view
            return View(productViewModel);
        }

        // URL:Products/Index
        public ActionResult Edit()
        {
            //Creating ViewModel object
            ProductViewModel productViewModel = new ProductViewModel();

            //Calling View and passing ViewModel object to view
            return View(productViewModel);
        }
    }
}
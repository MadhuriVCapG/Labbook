﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.DataAccessLayer;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting SalesPersons from SalesPersons collection.
    /// </summary>
    public class SalesPersonBL : BLBase<SalesPerson>, ISalesPersonBL, IDisposable
    {
        //fields
        SalesPersonDAL SalesPersonDAL;
        OrderBL orderbl = new OrderBL();


        /// <summary>
        /// Constructor.
        /// </summary>
        public SalesPersonBL()
        {
            this.SalesPersonDAL = new SalesPersonDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(SalesPerson entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetSalesPersonByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.SalespersonID != entityObject.SalespersonID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            if (valid == false)
                throw new GreatOutdoorsException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new SalesPerson to SalesPersons collection.
        /// </summary>
        /// <param name="newSalesPerson">Contains the SalesPerson details to be added.</param>
        /// <returns>Determinates whether the new SalesPerson is added.</returns>
        public async Task<bool> AddSalesPersonBL(SalesPerson newSalesPerson)
        {
            bool SalesPersonAdded = false;
            try
            {
                if (await Validate(newSalesPerson))
                {
                    await Task.Run(() =>
                    {
                        this.SalesPersonDAL.AddSalesPersonDAL(newSalesPerson);
                        SalesPersonAdded = true;
                    });
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonAdded;
        }

        /// <summary>
        /// Gets all SalesPersons from the collection.
        /// </summary>
        /// <returns>Returns list of all SalesPersons.</returns>
        public async Task<List<SalesPerson>> GetAllSalesPersonsBL()
        {
            List<SalesPerson> SalesPersonsList = null;
            try
            {
                await Task.Run(() =>
                {
                    SalesPersonsList = SalesPersonDAL.GetAllSalesPersonsDAL();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonsList;
        }

        /// <summary>
        /// Gets SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="searchSalesPersonID">Represents SalesPersonID to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonBySalesPersonIDBL(Guid searchSalesPersonID)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonBySalesPersonIDDAL(searchSalesPersonID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets SalesPerson based on SalesPersonName.
        /// </summary>
        /// <param name="SalesPersonName">Represents SalesPersonName to search.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<List<SalesPerson>> GetSalesPersonsByNameBL(string SalesPersonName)
        {
            List<SalesPerson> matchingSalesPersons = new List<SalesPerson>();
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPersons = SalesPersonDAL.GetSalesPersonsByNameDAL(SalesPersonName);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPersons;
        }

        /// <summary>
        /// Gets SalesPerson based on Email and Password.
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonByEmailBL(string email)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonByEmailDAL(email);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Gets SalesPerson based on Password.
        /// </summary>
        /// <param name="email">Represents SalesPerson's Email Address.</param>
        /// <param name="password">Represents SalesPerson's Password.</param>
        /// <returns>Returns SalesPerson object.</returns>
        public async Task<SalesPerson> GetSalesPersonByEmailAndPasswordBL(string email, string password)
        {
            SalesPerson matchingSalesPerson = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesPerson = SalesPersonDAL.GetSalesPersonByEmailAndPasswordDAL(email, password);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingSalesPerson;
        }

        /// <summary>
        /// Updates SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, SalesPersonName etc.</param>
        /// <returns>Determinates whether the existing SalesPerson is updated.</returns>
        public async Task<bool> UpdateSalesPersonBL(SalesPerson updateSalesPerson)
        {
            bool SalesPersonUpdated = false;
            try
            {
                if ((await Validate(updateSalesPerson)) && (await GetSalesPersonBySalesPersonIDBL(updateSalesPerson.SalespersonID)) != null)
                {
                    this.SalesPersonDAL.UpdateSalesPersonDAL(updateSalesPerson);
                    SalesPersonUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonUpdated;
        }

        /// <summary>
        /// Updates SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, SalesPersonName etc.</param>
        /// <returns>Determinates whether the existing SalesPerson is updated.</returns>
        public async Task<bool> UpdateSalesPersonDetailsBL(SalesPerson updateSalesPerson)
        {
            bool SalesPersonUpdated = false;
            try
            {
                if ((await Validate(updateSalesPerson)) && (await GetSalesPersonBySalesPersonIDBL(updateSalesPerson.SalespersonID)) != null)
                {
                    this.SalesPersonDAL.UpdateSalesPersonDetailsDAL(updateSalesPerson);
                    SalesPersonUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonUpdated;
        }

        /// <summary>
        /// Deletes SalesPerson based on SalesPersonID.
        /// </summary>
        /// <param name="deleteSalesPersonID">Represents SalesPersonID to delete.</param>
        /// <returns>Determinates whether the existing SalesPerson is updated.</returns>
        public async Task<bool> DeleteSalesPersonBL(Guid deleteSalesPersonID)
        {
            bool SalesPersonDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    SalesPersonDeleted = SalesPersonDAL.DeleteSalesPersonDAL(deleteSalesPersonID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return SalesPersonDeleted;
        }

        /// <summary>
        /// Updates SalesPerson's password based on SalesPersonID.
        /// </summary>
        /// <param name="updateSalesPerson">Represents SalesPerson details including SalesPersonID, Password.</param>
        /// <returns>Determinates whether the existing SalesPerson's password is updated.</returns>
        public async Task<bool> UpdateSalesPersonPasswordBL(SalesPerson updateSalesPerson)
        {
            bool passwordUpdated = false;
            try
            {
                if ((await Validate(updateSalesPerson)) && (await GetSalesPersonBySalesPersonIDBL(updateSalesPerson.SalespersonID)) != null)
                {
                    this.SalesPersonDAL.UpdateSalesPersonPasswordDAL(updateSalesPerson);
                    passwordUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return passwordUpdated;
        }


        /// <summary>
        /// Get the list of orders made by a salesperson.
        /// </summary>
        /// <param name="salesPersonID">Contains the Id of the salesperson who's saleIDs are required.</param>
        /// <returns>list of orders of salesperson.</returns>
        public async Task<List<Order>> GetSalesHistoryBL(Guid salesPersonID)
        {
            List<Order> sales = null;
            try
            {

                sales = await orderbl.GetOrderBySalesPersonIDBL(salesPersonID);

            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return sales;

        }
        
      


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            //((SalesPersonDAL)SalesPersonDAL).Dispose();
        }


    }
}




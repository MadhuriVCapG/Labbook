﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using GreatOutdoors.DataAccessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.BusinessLayer;

namespace GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for Products.xaml
    /// </summary>
    public partial class Products : Window
    {
        public static Product updtProduct = new Product();
        public Products()
        {
            InitializeComponent();
        }


        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgProducts.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }

            updtProduct.ProductID = Guid.Parse(getCellData(dgProducts, rowindex, 0));
            updtProduct.Name = getCellData(dgProducts, rowindex, 1);
            updtProduct.Category = getCellData(dgProducts, rowindex, 2);
            updtProduct.Stock = Int32.Parse(getCellData(dgProducts, rowindex, 3));
            updtProduct.Size = getCellData(dgProducts, rowindex, 4);
            updtProduct.Colour = getCellData(dgProducts, rowindex, 5);
            updtProduct.TechnicalSpecifications = getCellData(dgProducts, rowindex, 6);
            updtProduct.CostPrice = Decimal.Parse(getCellData(dgProducts, rowindex, 7));
            updtProduct.SellingPrice = Decimal.Parse(getCellData(dgProducts, rowindex, 8));
            updtProduct.DiscountPercentage = Decimal.Parse(getCellData(dgProducts, rowindex, 9));
        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                            dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;

            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;

            return cellContent.Text;

        }
        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            AddProduct window2 = new AddProduct();
            window2.Show();
            this.Close();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ProductBL productDAL = new ProductBL();
            List<Product> products = new List<Product>();
            products = productDAL.GetAllProductsDAL();
            dgProducts.ItemsSource = products;
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {

            int rowindex = dgProducts.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            Guid deleteID = Guid.Parse(getCellData(dgProducts, rowindex, 0));
            ProductDAL productDAL = new ProductDAL();
            bool isDeleted = productDAL.DeleteProductDAL(deleteID);
            if (isDeleted)
                MessageBox.Show("Product Deleted");
        }

        private void UpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            UpdateProduct window3 = new UpdateProduct();
            window3.Show();
            this.Close();
        }
    }
}
}

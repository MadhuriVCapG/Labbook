﻿using System;
using System.Windows;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for AddSalesPerson.xaml
    /// </summary>
    public partial class AddSalesPerson : Window
    {
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public AddSalesPerson()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersons();
            window.Show();
            this.Close();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            SalesPerson salesPerson = new SalesPerson();

            salesPerson.Name = txtName.Text;
            salesPerson.Mobile = txtMobile.Text;
            salesPerson.Email = txtEmail.Text;
            salesPerson.Password = txtPassword.Text;
            salesPerson.Pincode = txtPincode.Text;
            salesPerson.Salary = Convert.ToDecimal(txtSalary.Text);
            salesPerson.Target = Convert.ToDecimal(txtTarget.Text);
            salesPerson.Bonus = Convert.ToDecimal(txtBonus.Text);
            salesPerson.City = txtCity.Text;
            salesPerson.State = txtState.Text;
            salesPerson.AddressLine1 = txtAddressL1.Text;
            salesPerson.AddressLine2 = txtAddressL2.Text;
            salesPerson.Birthdate = Convert.ToDateTime(txtBirthDate.Text);
            salesPerson.JoiningDate = Convert.ToDateTime(txtJoiningDate.Text);

            bool isAdded = await salesPersonBL.AddSalesPersonBL(salesPerson);

            if (isAdded)
                MessageBox.Show("Sales person added successfully!");

            Window window = new SalesPersons();
            window.Show();
            this.Close();


        }
    }
}

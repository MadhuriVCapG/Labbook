﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for EditSalesPerson.xaml
    /// </summary>
    public partial class EditSalesPerson : Window
    {
        public EditSalesPerson()
        {
            InitializeComponent();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            SalesPersonHome.currentSalesPerson.Name = txtName.Text;
            SalesPersonHome.currentSalesPerson.Email = txtEmail.Text;
            SalesPersonHome.currentSalesPerson.Mobile = txtMobile.Text;
            SalesPersonHome.currentSalesPerson.Password = txtPassword.Password;
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            bool updated = await salesPersonBL.UpdateSalesPersonBL(SalesPersonHome.currentSalesPerson);
            bool password = await salesPersonBL.UpdateSalesPersonPasswordBL(SalesPersonHome.currentSalesPerson);

            if (updated && password)
                MessageBox.Show("Details updated successfully!");
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtName.Text = SalesPersonHome.currentSalesPerson.Name;
            txtEmail.Text = SalesPersonHome.currentSalesPerson.Email;
            txtMobile.Text = SalesPersonHome.currentSalesPerson.Mobile;
            txtPassword.Password = SalesPersonHome.currentSalesPerson.Password;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for UpdateSalesPerson.xaml
    /// </summary>
    public partial class UpdateSalesPerson : Window
    {
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public UpdateSalesPerson()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtBonus.Text = Convert.ToString(SalesPersons.salesPerson.Bonus);
            txtSalary.Text = Convert.ToString(SalesPersons.salesPerson.Salary);
            txtTarget.Text = Convert.ToString(SalesPersons.salesPerson.Target);
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            SalesPersons.salesPerson.Bonus = Convert.ToDecimal(txtBonus.Text);
            SalesPersons.salesPerson.Salary = Convert.ToDecimal(txtSalary.Text);
            SalesPersons.salesPerson.Target = Convert.ToDecimal(txtTarget.Text);

            bool isUpdated = await salesPersonBL.UpdateSalesPersonDetailsBL(SalesPersons.salesPerson);
            if (isUpdated)
                MessageBox.Show("Sales person updated successfully!");
            Window window = new SalesPersons();
            window.Show();
            this.Close();

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersons();
            window.Show();
            this.Close();
        }
    }
}

﻿using System;
using System.Windows;
using Capgemini.GreatOutdoors.BusinessLayer;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for UpdateProduct.xaml
    /// </summary>
    public partial class UpdateProduct : Window
    {
        ProductBL productBL = new ProductBL();

        public UpdateProduct()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            txtStock.Text = (Products.updtProduct.Stock).ToString();
            txtTechSpecs.Text = Products.updtProduct.TechnicalSpecifications;
            txtCostPrice.Text = (Products.updtProduct.CostPrice).ToString();
            txtSellingPrice.Text = (Products.updtProduct.SellingPrice).ToString();
            txtDiscountPercentage.Text = (Products.updtProduct.DiscountPercentage).ToString();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            Products.updtProduct.Stock = Convert.ToInt32(txtStock.Text);
            Products.updtProduct.TechnicalSpecifications = txtTechSpecs.Text;
            Products.updtProduct.SellingPrice = Convert.ToDecimal(txtSellingPrice.Text);
            Products.updtProduct.CostPrice = Convert.ToDecimal(txtCostPrice.Text);
            Products.updtProduct.DiscountPercentage = Convert.ToDecimal(txtDiscountPercentage.Text);

            
            bool updated = await productBL.UpdateProductDetailsBL(Products.updtProduct);
            bool stock = await productBL.UpdateProductStockBL(Products.updtProduct);
            bool discount = await productBL.UpdateProductDiscountBL(Products.updtProduct);

            if (updated && stock && discount)
                MessageBox.Show("Product Updated successfully!");
            Products window = new Products();
            window.Show();
            this.Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Products window = new Products();
            window.Show();
            this.Close();
        }
    }
}

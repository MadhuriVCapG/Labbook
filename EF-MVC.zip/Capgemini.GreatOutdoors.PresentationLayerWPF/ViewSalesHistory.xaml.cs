﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for ViewSalesHistory.xaml
    /// </summary>
    public partial class ViewSalesHistory : Window
    {
        OrderBL orderBL = new OrderBL();
        List<Order> orders = new List<Order>();
        public static Order selectedOrder = new Order();
        public ViewSalesHistory()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            orders = await orderBL.GetOrderBySalesPersonIDBL(SalesPersonHome.currentSalesPerson.SalespersonID);
            dgSalesHistory.ItemsSource = orders;
            
        }

        private void BtnViewDetails_Click(object sender, RoutedEventArgs e)
        {
          //  Window window = new ViewOrderDetails();
          //  window.Show();
            this.Close();
        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                            dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;

            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;

            return cellContent.Text;

        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();
        }

        private void DgSalesHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgSalesHistory.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }

            selectedOrder.OrderID = Guid.Parse(getCellData(dgSalesHistory, rowindex, 0));
            selectedOrder.RetailerID = Guid.Parse(getCellData(dgSalesHistory, rowindex, 1));
            selectedOrder.SalespersonID = SalesPersonHome.currentSalesPerson.SalespersonID;
            selectedOrder.TotalQuantity = Int32.Parse(getCellData(dgSalesHistory, rowindex, 3));
            selectedOrder.TotalAmount = Decimal.Parse(getCellData(dgSalesHistory, rowindex, 3));
            selectedOrder.ChannelOfSale = getCellData(dgSalesHistory, rowindex, 4);
            selectedOrder.OrderDateTime = DateTime.Parse(getCellData(dgSalesHistory, rowindex, 5));
            selectedOrder.ModifiedDateTime = DateTime.Parse(getCellData(dgSalesHistory, rowindex, 6));
        }
    }
}

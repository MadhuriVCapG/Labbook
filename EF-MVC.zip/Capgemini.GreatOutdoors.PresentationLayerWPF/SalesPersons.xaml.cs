﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.PresentationLayerWPF
{
    /// <summary>
    /// Interaction logic for SalesPersons.xaml
    /// </summary>
    public partial class SalesPersons : Window
    {
        public static SalesPerson salesPerson = new SalesPerson();
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public SalesPersons()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgSalesPersons.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }

            salesPerson.SalespersonID = Guid.Parse(getCellData(dgSalesPersons, rowindex, 0));
            salesPerson.Name = getCellData(dgSalesPersons, rowindex, 1);
            salesPerson.Mobile = getCellData(dgSalesPersons, rowindex, 2);
            salesPerson.Email = getCellData(dgSalesPersons, rowindex, 3);
            salesPerson.Password = getCellData(dgSalesPersons, rowindex, 4);
            salesPerson.Salary = Decimal.Parse(getCellData(dgSalesPersons, rowindex, 5));
            salesPerson.Bonus = Decimal.Parse(getCellData(dgSalesPersons, rowindex, 6));
            salesPerson.Target = Decimal.Parse(getCellData(dgSalesPersons, rowindex, 7));
            salesPerson.JoiningDate = Convert.ToDateTime(getCellData(dgSalesPersons, rowindex, 8));
            salesPerson.AddressLine1= getCellData(dgSalesPersons, rowindex, 9);
            salesPerson.AddressLine2 = getCellData(dgSalesPersons, rowindex, 10);
            salesPerson.City = getCellData(dgSalesPersons, rowindex, 11);
            salesPerson.State = getCellData(dgSalesPersons, rowindex, 12);
            salesPerson.Pincode = getCellData(dgSalesPersons, rowindex, 13);
            salesPerson.Birthdate = Convert.ToDateTime(getCellData(dgSalesPersons, rowindex, 14));
            
            
        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                            dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;

            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;

            return cellContent.Text;

        }
        private void AddSalesPerson_Click(object sender, RoutedEventArgs e)
        {
           AddSalesPerson window2 = new AddSalesPerson();
            window2.Show();
            this.Close();

        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {

            List<SalesPerson> salespeople = new List<SalesPerson>();
            salespeople = await(salesPersonBL.GetAllSalesPersonsBL());
            dgSalesPersons.ItemsSource = salespeople;
        }

        private async void DeleteSalesPerson_Click(object sender, RoutedEventArgs e)
        {

            int rowindex = dgSalesPersons.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            Guid deleteID = Guid.Parse(getCellData(dgSalesPersons, rowindex, 0));

            bool isDeleted = await salesPersonBL.DeleteSalesPersonBL(deleteID);
            if (isDeleted)
                MessageBox.Show("SalesPerson Deleted");
        }

        private void UpdtSalesPerson_Click(object sender, RoutedEventArgs e)
        {
           UpdateSalesPerson window3 = new UpdateSalesPerson();
                window3.Show();
            this.Close();
        }
    }
}

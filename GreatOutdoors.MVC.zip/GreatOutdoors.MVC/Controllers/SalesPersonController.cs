﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace GreatOutdoors.MVC.Controllers
{
    public class SalesPersonController : Controller
    {
        // GET: SalesPerson
        public async Task<ActionResult> Home()
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            Guid currentSalesPersonID = (Guid)Session["SalesPersonID"];
            SalesPersonBL salesPersonBL = new SalesPersonBL();

            SalesPerson salesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(currentSalesPersonID);

            salesPersonViewModel.SalespersonID = salesPerson.SalespersonID;
            salesPersonViewModel.Name = salesPerson.Name;
            salesPersonViewModel.Mobile = salesPerson.Mobile;
            salesPersonViewModel.Email = salesPerson.Email;
            salesPersonViewModel.JoiningDate = salesPerson.JoiningDate;
            salesPersonViewModel.Salary = salesPerson.Salary;
            salesPersonViewModel.Bonus = salesPerson.Bonus;
            salesPersonViewModel.Target = salesPerson.Target;

            return View(salesPersonViewModel);
        }


        public async Task<ActionResult> Edit(Guid id)
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(id);

            salesPersonViewModel.Name = currentSalesPerson.Name;
            salesPersonViewModel.Mobile = currentSalesPerson.Mobile;
            salesPersonViewModel.Email = currentSalesPerson.Email;
            salesPersonViewModel.SalespersonID = id;

            return View(salesPersonViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Edit(SalesPersonViewModel salesPersonViewModel)
        {
           
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(salesPersonViewModel.SalespersonID);

            currentSalesPerson.Name = salesPersonViewModel.Name;
            currentSalesPerson.Email = salesPersonViewModel.Email;
            currentSalesPerson.Mobile = salesPersonViewModel.Mobile;

            bool isUpdated = await salesPersonBL.UpdateSalesPersonBL(currentSalesPerson);

            if (isUpdated)
                return RedirectToAction("Home");
            else
                return Content("Your profile could not be updated.");
        }

        public async Task<ActionResult> ChangePassword(Guid id)
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(id);

            salesPersonViewModel.Password = currentSalesPerson.Password;
            salesPersonViewModel.Name = currentSalesPerson.Name;

            return View(salesPersonViewModel);
        }

    }
}
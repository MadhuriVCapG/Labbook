﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GreatOutdoors.Entities;

namespace GreatOutdoors.MVC.Controllers
{
    public class TestController : ApiController
    {
        TeamAEntities entities = new TeamAEntities();
        public IHttpActionResult getAllProducts()
        {
            List<Product> products = entities.GetAllProducts().ToList();

            if (products == null)
                return NotFound();
            else
                return Ok(products);
        }
    }
}

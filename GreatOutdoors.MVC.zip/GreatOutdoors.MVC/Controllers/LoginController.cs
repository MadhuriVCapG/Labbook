﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            LoginViewModel loginViewModel = new LoginViewModel();

            return View(loginViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel loginViewModel)
        {
            
            if (loginViewModel.UserType == "Admin")
            {
                Admin admin = new Admin();
                AdminBL adminBL = new AdminBL();
                admin = await adminBL.GetAdminByEmailAndPasswordBL(loginViewModel.Email, loginViewModel.Password);
                if (admin != null)
                {
                    Session["AdminID"] = admin.AdminID;
                    return RedirectToAction("");
                }
                else
                {
                    return Content("Record Not Found");
                }
            }

            if (loginViewModel.UserType == "Sales Person")
            {
                SalesPerson salesPerson = new SalesPerson();
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(loginViewModel.Email, loginViewModel.Password);
                if (salesPerson != null)
                {
                    Session["SalesPersonID"] = salesPerson.SalespersonID;
                    return RedirectToAction("Home","SalesPerson");
                }
                else
                {
                    return Content("Record Not Found");
                }

            }

            if (loginViewModel.UserType == "Retailer")
            {
                Retailer retailer = new Retailer();
                RetailerBL retailerBL = new RetailerBL();
                retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(loginViewModel.Email, loginViewModel.Password);
                if (retailer != null)
                {
                    Session["RetailerID"] = retailer.RetailerID;
                    return RedirectToAction("");
                }
                else
                {
                    return Content("Record Not Found");
                }

            }

            else
                Content("Invalid User Type!!");

            return View();

        }
    }
}
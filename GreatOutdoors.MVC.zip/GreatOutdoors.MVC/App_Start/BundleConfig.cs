﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Optimization;

namespace GreatOutdoors.MVC
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles )
        {
            //Bundle - jquery and popper.js
            bundles.Add(new ScriptBundle("~/scripts/jquery").Include("~/Scripts/jquery-3.4.1.js", "~/Scripts/umd/popper.js"));

            //Bundle - validate and validate.unobtrusive
            bundles.Add(new ScriptBundle("~/scripts/jqueryvalidation").Include("~/Scripts/jquery.validate.js", "~/Scripts/jquery.validate.unobtrusive.js"));

            //Bundle - Bootstrap
            bundles.Add(new ScriptBundle("~/scripts/bootstrap").Include("~/Scripts/bootstrap.js"));

            BundleTable.EnableOptimizations = true;

        }
    }
}
﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    public enum ReturnReasons { Wrong, Incomplete }
    public interface IReturnDetails
    {
        Guid ReturnDetailID { get; set; }
        Guid ReturnID { get; set; }
        Guid ProductID { get; set; }
        int Quantity { get; set; }
        ReturnReasons ReasonOfReturn { get; set; }
        double UnitPrice { get; set; }
        Guid AddressID { get; set; }
        double TotalPrice { get; set; }
    }
    public class ReturnDetails : IReturnDetails
    {

        /* Auto-Implemented Properties */
        [Required("ReturnDetail ID can't be blank.")]
        public Guid ReturnDetailID { get; set; }

        [Required("Return ID can't be blank.")]
        public Guid ReturnID { get; set; }

        [Required("Product ID can't be blank.")]
        public Guid ProductID { get; set; }

        [Required("Quantity can't be blank.")]
        public int Quantity { get; set; }
        [Required("Reason can't be blank.")]
        public ReturnReasons ReasonOfReturn { get; set; }


        [Required("Unit price can't be blank.")]
        public double UnitPrice { get; set; }

        [Required("Address ID can't be blank.")]
        public Guid AddressID { get; set; }

        [Required("Total Price can't be blank.")]
        public double TotalPrice { get; set; }


        /* Constructor */
        public ReturnDetails()
        {
            ReturnDetailID = default(Guid);
            ReturnID = default(Guid);
            ProductID = default(Guid);
            Quantity = 0;
            ReasonOfReturn = ReturnReasons.Wrong;
            UnitPrice = 0;
            AddressID = default(Guid);
            TotalPrice = 0;
        }
    }
}


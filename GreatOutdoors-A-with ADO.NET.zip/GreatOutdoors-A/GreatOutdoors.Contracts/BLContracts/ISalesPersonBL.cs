﻿using Capgemini.GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface ISalesPersonBL : IDisposable
    {
        Task<bool> AddSalesPersonBL(SalesPerson newSalesPerson);
        Task<List<SalesPerson>> GetAllSalesPersonsBL();
        Task<SalesPerson> GetSalesPersonBySalesPersonIDBL(Guid searchSalesPersonID);
        Task<List<SalesPerson>> GetSalesPersonsByNameBL(string salesPersonName);
        Task<SalesPerson> GetSalesPersonByEmailBL(string email);
        Task<SalesPerson> GetSalesPersonByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateSalesPersonBL(SalesPerson updateSalesPerson);
        Task<bool> UpdateSalesPersonPasswordBL(SalesPerson updateSalesPerson);
        Task<bool> DeleteSalesPersonBL(Guid deleteSalesPersonID);
        Task<List<Order>> GetSalesHistoryBL(Guid salesPersonID);
        Task<Order> SearchSalesBL(Guid searchSalesID, Guid salesPersonID);
        Task<bool> AddSalesOrderBL(Order newOrder);
        Task<List<Order>> ViewActiveOrdersBL();
        Task<bool> AcceptOrderForSaleBL(Guid activeOrderID, Guid salesPersonID);
        Task<bool> ModifySalesOrderBL(Order updatedOrder);
        Task<bool> ConfirmSalesOrderBL(Guid confirmOrderID, Guid salesPersonID);
    }
}



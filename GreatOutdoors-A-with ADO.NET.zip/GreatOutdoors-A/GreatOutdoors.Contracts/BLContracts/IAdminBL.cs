﻿using System;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IAdminBL : IDisposable
    {
        Task<Admin> GetAdminByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateAdminBL(Admin updateAdmin);
        Task<bool> UpdateAdminPasswordBL(Admin updateAdmin);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IOrdersBL : IDisposable
    {

        Task<(bool, Guid)> AddOrderBL(Order newOrder);
        Task<List<Order>> GetAllOrdersBL();
        Task<Order> GetOrderByOrderIDBL(Guid searchOrderID);
        Task<List<Order>> GetOrderByRetailerIDBL(Guid retailerID);
        Task<List<Order>> GetOrderBySalesPersonIDBL(Guid salesPersonID);
        Task<List<Order>> GetOrderForOfflineSaleBL();
        Task<List<Order>> GetOrderOnlineBL();
        //Task<List<Order>> GetOrderByStatusBL(Status currentStatus);
        Task<bool> UpdateOrderBL(Order updateOrder);
        //Task<bool> UpdateOrderStatusBL(Order updateOrder);
        Task<bool> DeleteOrderByOrderID(Guid orderID);



    }
}

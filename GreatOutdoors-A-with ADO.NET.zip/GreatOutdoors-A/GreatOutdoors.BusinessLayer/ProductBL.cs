﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DataAccessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting Products from Products collection.
    /// </summary>
    public class ProductBL : BLBase<Product>, IProductBL, IDisposable
    {
        //fields
        ProductDALBase ProductDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public ProductBL()
        {
            this.ProductDAL = new ProductDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Product entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            if (valid == false)
                throw new Exception(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new Product to Products collection.
        /// </summary>
        /// <param name="newProduct">Contains the Product details to be added.</param>
        /// <returns>Determinates whether the new Product is added.</returns>
        public async Task<bool> AddProductBL(Product newProduct)
        {
            bool ProductAdded = false;
            try
            {
                if (await Validate(newProduct))
                {
                    await Task.Run(() =>
                    {
                        this.ProductDAL.AddProductDAL(newProduct);
                        ProductAdded = true;
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return ProductAdded;
        }

        /// <summary>
        /// Gets all Products from the collection.
        /// </summary>
        /// <returns>Returns list of all Products.</returns>
        public async Task<List<Product>> GetAllProductsBL()
        {
            List<Product> ProductsList = null;
            try
            {
                await Task.Run(() =>
                {
                    ProductsList = ProductDAL.GetAllProductsDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return ProductsList;
        }

        /// <summary>
        /// Gets Product based on ProductID.
        /// </summary>
        /// <param name="searchProductID">Represents ProductID to search.</param>
        /// <returns>Returns Product object.</returns>
        public async Task<Product> GetProductByProductIDBL(Guid searchProductID)
        {
            Product matchingProduct = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingProduct = ProductDAL.GetProductByProductIDDAL(searchProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingProduct;
        }

        /// <summary>
        /// Gets Product based on ProductName.
        /// </summary>
        /// <param name="ProductName">Represents ProductName to search.</param>
        /// <returns>Returns Product object.</returns>
        public async Task<Product> GetProductByNameBL(string ProductName)
        {
            Product matchingProduct = new Product();
            try
            {
                await Task.Run(() =>
                {
                    matchingProduct = ProductDAL.GetProductByNameDAL(ProductName);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingProduct;
        }

        /// <summary>
        /// Gets Product based on Category.
        /// </summary>
        /// <param name="categoryName">Represents Product's Category</param>
        /// <returns>Returns Product object.</returns>
        public async Task<List<Product>> GetProductByCategoryBL(Category categoryName)
        {
            List<Product> matchingProduct = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingProduct = ProductDAL.GetProductsByCategoryDAL(categoryName);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingProduct;
        }



        /// <summary>
        /// Updates Product based on ProductID.
        /// </summary>
        /// <param name="updateProduct">Represents Product details including ProductID, ProductName etc.</param>
        /// <returns>Determinates whether the existing Product is updated.</returns>
        public async Task<bool> UpdateProductBL(Product updateProduct)
        {
            bool ProductUpdated = false;
            try
            {
                if ((await Validate(updateProduct)) && (await GetProductByProductIDBL(updateProduct.ProductID)) != null)
                {
                    this.ProductDAL.UpdateProductDAL(updateProduct);
                    ProductUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return ProductUpdated;
        }


        /// <summary>
        /// Updates product stock.
        /// </summary>
        /// <param name="updateProduct">Represents Product details including ProductID, ProductName etc.</param>
        /// <returns>Determinates whether the existing Product is updated.</returns>
        public async Task<bool> UpdateProductStockBL(Product updateProduct)
        {
            bool StockUpdated = false;
            try
            {
                if ((await Validate(updateProduct)) && (await GetProductByProductIDBL(updateProduct.ProductID)) != null)
                {
                    this.ProductDAL.UpdateProductStockDAL(updateProduct);
                    StockUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return StockUpdated;
        }

        /// <summary>
        /// Updates product discount.
        /// </summary>
        /// <param name="updateProduct">Represents Product details including ProductID, ProductName etc.</param>
        /// <returns>Determinates whether the existing Product is updated.</returns>
        public async Task<bool> UpdateProductDiscountBL(Product updateProduct)
        {
            bool discountUpdated = false;
            try
            {
                if ((await Validate(updateProduct)) && (await GetProductByProductIDBL(updateProduct.ProductID)) != null)
                {
                    this.ProductDAL.UpdateProductDiscountDAL(updateProduct);
                    discountUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return discountUpdated;
        }


        /// <summary>
        /// Deletes Product based on ProductID.
        /// </summary>
        /// <param name="deleteProductID">Represents ProductID to delete.</param>
        /// <returns>Determinates whether the existing Product is updated.</returns>
        public async Task<bool> DeleteProductBL(Guid deleteProductID)
        {
            bool ProductDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    ProductDeleted = ProductDAL.DeleteProductDAL(deleteProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return ProductDeleted;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((ProductDAL)ProductDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}




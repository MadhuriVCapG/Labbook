﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoors.UnitTests
{
    [TestClass]
    public class AddReturnBLTest
    {
        [TestMethod]
        public async Task AddValidReturn()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 1000, ReturnDateTime = DateTime.Now };
            bool isAdded = false;
            Guid Id = default(Guid);
            string errorMessage = null;
            //call AddOrder and get OrderID
            //assign the same to 
            OrderBL orderBL = new OrderBL();
            bool orderAdded = false;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            try
            {

                (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            }
            catch (Exception ex)
            {
                isAdded = false;
                Id = default(Guid);
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

    }   //

    [TestClass]
    public class GetReturnsBL
    {
        [TestMethod]
        public async Task ValidGetAllReturns()
        {
            bool isFetched = false;
            bool isAdded;
            Guid Id;
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 1000, ReturnDateTime = DateTime.Now };
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            string errorMessage = null;
            (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            try
            {

                List<Return> returnList = await returnBL.GetAllReturnsBL();
                Return returnObj1 = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Online, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
                OrderBL orderBL1 = new OrderBL();

                Order order1 = new Order();
                (orderAdded, orderIDFromOrderClass) = await orderBL1.AddOrderBL(order);
                returnObj1.OrderID = orderIDFromOrderClass;

                (isAdded, Id) = await returnBL.AddReturnBL(returnObj1);
                List<Return> returnListNow = await returnBL.GetAllReturnsBL();
                if (returnListNow.Count == returnList.Count + 1)
                {
                    isFetched = true;
                }

            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }

        }

        public async Task ValidGetReturnByReturnIDBL()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            Guid Id;
            (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            try
            {
                Return returnObj1 = await returnBL.GetReturnByReturnIDBL(Id);
                if (returnObj.ReturnID == Id)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }
        [TestMethod]
        public async Task InvalidGetReturnByReturnIDBL()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            Guid Id;
            (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            Guid returnIDNew = Guid.NewGuid();

            try
            {
                Return returnObj1 = await returnBL.GetReturnByReturnIDBL(returnIDNew);
                if (returnObj1.ReturnID == null)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }

        [TestMethod]
        public async Task ValidGetReturnByOrderIDBL()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            Guid Id;
            (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            try
            {
                List<Return> listOfReturns = await returnBL.GetReturnByOrderIDBL(Id);
                if (listOfReturns[0].ReturnID == returnObj.ReturnID)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }

        [TestMethod]
        public async Task InvalidGetReturnByOrderIDBL()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isFetched = false;
            bool isAdded = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            Guid Id;
            (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            Guid orderIdNew = Guid.NewGuid();

            try
            {
                List<Return> listOfReturns = await returnBL.GetReturnByOrderIDBL(orderIdNew);
                if (listOfReturns == null)
                    isFetched = true;
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }
    }


    [TestClass]
    public class DeleteReturnBLTest
    {
        [TestMethod]
        public async Task ValidDeleteReturnBLTest()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isDeleted = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;

            try
            {
                isDeleted = await returnBL.DeleteReturnBL(returnObj.ReturnID);
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isDeleted, errorMessage);
            }

        }

        [TestMethod]
        public async Task InValidDeleteReturnBLTest()
        {
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 800, ReturnDateTime = DateTime.Now };
            bool isDeleted = false;
            string errorMessage = null;
            OrderBL orderBL = new OrderBL();
            bool orderAdded;
            Guid orderIDFromOrderClass;
            Order order = new Order();
            (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
            returnObj.OrderID = orderIDFromOrderClass;
            Guid Id = Guid.NewGuid();
            try
            {
                isDeleted = await returnBL.DeleteReturnBL(returnObj.ReturnID);
            }
            catch (Exception ex)
            {
                isDeleted = true;
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isDeleted, errorMessage);
            }

        }

    }


}
